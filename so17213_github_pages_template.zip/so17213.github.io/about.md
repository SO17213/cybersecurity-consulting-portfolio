---
layout: page
title: "About Me"
permalink: /about/
---

Hi, I’m **Segun Oladipo**, a cybersecurity professional with experience in:

- Detection engineering
- Incident response
- Automation
- Cloud and endpoint security

This portfolio demonstrates real-world scenarios I’ve handled using Splunk, CrowdStrike, Chronicle, QRadar, and more.
