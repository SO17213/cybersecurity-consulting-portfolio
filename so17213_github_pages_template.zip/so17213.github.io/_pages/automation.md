---
layout: page
title: "Automation"
permalink: /automation/
---

This section covers key concepts and use cases in **Automation**.
More content will be added soon.
